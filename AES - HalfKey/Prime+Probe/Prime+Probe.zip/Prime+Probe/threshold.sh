rm -f values.dat
./spy > /dev/null 2>&1
gnuplot threshold.gnuplot
